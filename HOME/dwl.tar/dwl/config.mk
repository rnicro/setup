_VERSION = 0.9
VERSION  = `git describe --tags --dirty 2>/dev/null || echo $(_VERSION)`

PKG_CONFIG = pkg-config

PREFIX = /usr/local
MANDIR = $(PREFIX)/share/man
DATADIR = $(PREFIX)/share

WLR_INCS = `$(PKG_CONFIG) --cflags wlroots-0.20`
WLR_LIBS = `$(PKG_CONFIG) --libs wlroots-0.20`

XWAYLAND =
XLIBS =

CFLAGS=-march=skylake -O2 -pipe
LDFLAGS=-Wl,-O1,--as-needed,-s
CC = cc
