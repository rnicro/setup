#define COLOR(hex) {((hex>>24)&0xFF)/255.0f,((hex>>16)&0xFF)/255.0f,((hex>>8)&0xFF)/255.0f,(hex&0xFF)/255.0f}

static const int sloppyfocus=1;
static const int bypass_surface_visibility=0;
static const unsigned int borderpx=1;
static const unsigned int snap=10;

static const float rootcolor[]=COLOR(0x000000ff);
static const float bordercolor[]=COLOR(0x1a1c1fff);
static const float focuscolor[]=COLOR(0x3e434aff);
static const float urgentcolor[]=COLOR(0x8b9199ff);
static const float fullscreen_bg[]=COLOR(0x000000ff);

#define TAGCOUNT 5

static int log_level=WLR_ERROR;

static const Rule rules[]={
	{ "EXAMPLE",NULL,0,0,-1 },
};

static const Layout layouts[]={
	{ "[]=",tile },
	{ "><>",NULL },
	{ "[M]",monocle },
};

static const MonitorRule monrules[]={
	{ NULL,0.5f,1,1,&layouts[0],WL_OUTPUT_TRANSFORM_NORMAL,-1,-1 },
};

static const struct xkb_rule_names xkb_rules={
	.options=NULL,
};

static const int repeat_rate=25;
static const int repeat_delay=600;

static const int tap_to_click=1;
static const int tap_and_drag=1;
static const int drag_lock=1;
static const int natural_scrolling=1;
static const int disable_while_typing=1;
static const int left_handed=0;
static const int middle_button_emulation=0;

static const enum libinput_config_scroll_method scroll_method=LIBINPUT_CONFIG_SCROLL_2FG;
static const enum libinput_config_click_method click_method=LIBINPUT_CONFIG_CLICK_METHOD_BUTTON_AREAS;
static const uint32_t send_events_mode=LIBINPUT_CONFIG_SEND_EVENTS_ENABLED;
static const enum libinput_config_accel_profile accel_profile=LIBINPUT_CONFIG_ACCEL_PROFILE_ADAPTIVE;
static const double accel_speed=0.0;
static const enum libinput_config_tap_button_map button_map=LIBINPUT_CONFIG_TAP_MAP_LRM;

#define MODKEY WLR_MODIFIER_LOGO

#define TAGKEYS(KEY,TAG) \
	{ MODKEY,KEY,view,{.ui=1<<TAG} }, \
	{ MODKEY|WLR_MODIFIER_SHIFT,KEY,tag,{.ui=1<<TAG} }

#define SHCMD(cmd) { .v=(const char*[]){ "/bin/sh","-c",cmd,NULL } }

static const char *termcmd[]={"foot",NULL};
static const char *menucmd[]={"./.config/tofi/tofi-status.sh",NULL};

static const Key keys[]={
	{ MODKEY,XKB_KEY_t,spawn,{.v=termcmd} },
	{ MODKEY,XKB_KEY_d,spawn,{.v=menucmd} },

	{ 0,XKB_KEY_Print,spawn,SHCMD("grim ~/Pictures/$(date +'%Y-%m-%d_%H%M%S.png')") },
	{ MODKEY,XKB_KEY_n,spawn,SHCMD("pkill wlsunset || wlsunset -t 4000 -T 4001") },

	{ MODKEY,XKB_KEY_q,killclient,{0} },
	{ MODKEY,XKB_KEY_f,togglefullscreen,{0} },
	{ MODKEY,XKB_KEY_space,togglefloating,{0} },

	{ MODKEY,XKB_KEY_j,focusstack,{.i=+1} },
	{ MODKEY,XKB_KEY_k,focusstack,{.i=-1} },

	{ MODKEY,XKB_KEY_i,incnmaster,{.i=+1} },
	{ MODKEY,XKB_KEY_o,incnmaster,{.i=-1} },
	{ MODKEY,XKB_KEY_h,setmfact,{.f=-0.05f} },
	{ MODKEY,XKB_KEY_l,setmfact,{.f=+0.05f} },
	{ MODKEY,XKB_KEY_Return,zoom,{0} },

	{ MODKEY|WLR_MODIFIER_SHIFT,XKB_KEY_t,setlayout,{.v=&layouts[0]} },
	{ MODKEY|WLR_MODIFIER_SHIFT,XKB_KEY_f,setlayout,{.v=&layouts[1]} },
	{ MODKEY|WLR_MODIFIER_SHIFT,XKB_KEY_m,setlayout,{.v=&layouts[2]} },

	TAGKEYS(XKB_KEY_1,0),
	TAGKEYS(XKB_KEY_2,1),
	TAGKEYS(XKB_KEY_3,2),
	TAGKEYS(XKB_KEY_4,3),
	TAGKEYS(XKB_KEY_5,4),

	{ 0,XKB_KEY_XF86AudioMute,spawn,SHCMD("wpctl set-mute @DEFAULT_AUDIO_SINK@ toggle") },
	{ 0,XKB_KEY_XF86AudioLowerVolume,spawn,SHCMD("wpctl set-volume @DEFAULT_AUDIO_SINK@ 4%-") },
	{ 0,XKB_KEY_XF86AudioRaiseVolume,spawn,SHCMD("wpctl set-volume -l 1.0 @DEFAULT_AUDIO_SINK@ 4%+") },

	{ 0,XKB_KEY_XF86MonBrightnessDown,spawn,SHCMD("brightnessctl -q set 2%-") },
	{ 0,XKB_KEY_XF86MonBrightnessUp,spawn,SHCMD("brightnessctl -q set +2%") },

#define CHVT(n) { WLR_MODIFIER_CTRL|WLR_MODIFIER_ALT,XKB_KEY_F##n,chvt,{.ui=n} }
	CHVT(1),CHVT(2),
};

static const Button buttons[]={
	{ MODKEY,BTN_LEFT,moveresize,{.ui=CurMove} },
	{ MODKEY,BTN_RIGHT,moveresize,{.ui=CurResize} },
};

static const Axis axes[]={
	{ 0, 0, NULL, {0} },
};
